# -*- coding: utf-8 -*-
"""
Created on Mon Feb 12 12:49:29 2024

@author: Shivangi Prajapati N0909947
"""

#######################################################
#  Initialise AIML agent
#######################################################
import aiml
import csv
from csv import writer
import pandas as pd 
import numpy as np
import nltk
from nltk.stem import WordNetLemmatizer
from nltk.corpus import wordnet
from nltk.sem import Expression

from nltk.inference import ResolutionProver
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

import tkinter as tk
from tkinter import filedialog
import os
from tensorflow.keras.models import load_model
import math_classifier
import FuzzyGame as fg

import pyttsx3
import speech_recognition as sr
import sys


#######################################################
# Variables
#######################################################
## read csv file in question and answer
csvData = []
csvQuestions = []
csvAnswers = []
threshold = 0.5

#print(csvQuestions)
# Create a Kernel object. No string encoding (all I/O is unicode)
kern = aiml.Kernel()
kern.setTextEncoding(None)
kern.bootstrap(learnFiles="mybot-basic.xml")
lemmatizer = WordNetLemmatizer()
read_expr = Expression.fromstring
resolution_prover = ResolutionProver()

model = load_model("mathModel.h5")  #load the model 


# read the second knoledge base file 
knowledgeBase=[]
data = pd.read_csv('KB.csv', header=None)
[knowledgeBase.append(read_expr(row)) for row in data[0]]


## check for the intergrety of the KB
mainDirectory = os.path.join(os.getcwd(), 'Images');

display_answer = "No match found"
error_message = ""
def checkKb(kb):
    answer = resolution_prover.prove(None , knowledgeBase, verbose=False)
    if answer:
        print("The knowledge base has contradiction")
        sys.exit()
        
checkKb(knowledgeBase)

#######################################################
# Welcome user
#######################################################
print("""
\t\t------------------------------------------------------------
\t\t\t   __  __         _    _      _             _   
\t\t\t  |  \/  |       | |  | |    | |           | |  
\t\t\t  | \  / |  __ _ | |_ | |__  | |__    ___  | |_ 
\t\t\t  | |\/| | / _` || __|| '_ \ | '_ \  / _ \ | __|
\t\t\t  | |  | || (_| || |_ | | | || |_) || (_) || |_ 
\t\t\t  |_|  |_| \__,_| \__||_| |_||_.__/  \___/  \__|
                                              
\t\t------------------------------------------------------------
""")


def readCsvFile(fileName):
    with open(fileName, 'r') as csv_file:
        my_reader = csv.reader(csv_file, skipinitialspace=True)
        for row in my_reader:
            question,response = row
            csvQuestions.append(question.lower())
            csvAnswers.append(response)
            csvData.append((question.strip(), response.strip()))
           # print(csvData)
    csvQuestions.pop(0)
    csvAnswers.pop(0)
    
    
def getSimilarity(user_lamma,csvQuestion_lamma):
    # similarity code in here
    ## word counter 
  #  countVec = CountVectorizer()
    tfidfVec = TfidfVectorizer()
    
    tdf_matrix = tfidfVec.fit_transform([user_lamma] + csvQuestions)
    #user_matrix = tfidfVec.transform([userInput])
    #print("tdf Matrix1:",tdf_matrix )
    
    tdf_similarity = cosine_similarity(tdf_matrix[0:1], tdf_matrix[1:]).flatten()
    #print("similairity1:",tdf_similarity)
    max_similarity_index = np.argmax(tdf_similarity)
  
    if tdf_similarity[max_similarity_index] > threshold:     
        return max_similarity_index
    else:
        return -1;
    
        
def getTokens(sentence):
    sentence_tokens = nltk.word_tokenize(sentence)
    pos_tags = nltk.pos_tag(sentence_tokens)
    lemmatized_output = ' '.join([lemmatizer.lemmatize(token, getRootForm(pos_tag)) for token, pos_tag in pos_tags])
    return lemmatized_output
    
    
def getRootForm(sentence):
    if sentence.startswith('J'):
        return wordnet.ADJ
    elif sentence.startswith('V'):
        return wordnet.VERB
    elif sentence.startswith('N'):
        return wordnet.NOUN
    elif sentence.startswith('R'):
        return wordnet.ADV
    else:
        return wordnet.NOUN
    

def addToKb(expr):
    with open('KB.csv', 'a', newline='') as file: 
        writerObj = writer(file)     
        writerObj.writerow(expr)
        file.close()

def getFile():
    root = tk.Tk()
    folder_selected = filedialog.askdirectory()
    file_path = filedialog.askopenfilename(
        initialdir = mainDirectory,
        title="Select File",
        filetypes=(("All files", "*.jpg;*.jpeg;*.png;*.gif, *mp4, *.avi, *.mov"), ("All files", "*.*")))
    root.destroy()
    return file_path


def responseHelper(response):
    print(response) 
    if not user_selection == "stop":
       readResponse(response)
    # always print
    



def getResponeQA(userInput):
    readCsvFile("Q&A.csv");
    #perfome lemmatation for user input and csv questions
    user_lemma = getTokens(userInput)             
    csvQuestion_lemma = []            
    for i, question in enumerate(csvQuestions):
        question = getTokens(question)
        csvQuestion_lemma.append(question)
       
    #Index of the most similar question
    answerIndex = getSimilarity(user_lemma, csvQuestion_lemma)    
    return answerIndex
    

def getAnswer(method,expr):
    # check if the statemet already exists
    answer=resolution_prover.prove(expr, knowledgeBase, verbose=False)
    if answer:   
        #print("Correct!")
        responseHelper("Correct!");
        return False
    else:
        #check for contracdiction before storing in the KB
        #print("It may not be true... let me check...")
        responseHelper("It may not be true... let me check...");
        answer = resolution_prover.prove(expr.negate(), knowledgeBase, verbose=False)
        if answer:
            # contradiction found
            msg = "I know that is not true."  if method == 1  else "Incorrect"
           # print(msg)
            responseHelper(msg)
            return False
        # no contraction found
        else:
         return True
        
        ## no contraction , can add to KB
         
    

def getUserResponse(userInput):
    #get user input
    responseAgent = 'aiml'
    if responseAgent == 'aiml':
        answer = kern.respond(userInput)
        
    # check for the response received
    if answer[0] == '#':
        params = answer[1:].split('$')
        cmd = int(params[0])
        if cmd == 0:
            responseHelper(params[1])
            #break
        elif cmd == 31:
            object,subject=params[1].split(' is ')
            expr=read_expr(subject + '(' + object + ')')    
           # expr =  getAnswer(1, object , subject)
            if getAnswer(1, expr):
                knowledgeBase.append(expr) 
                # prepare expressions for lines
                expression = str(expr)
                if "line" in expression:
                    expression = "isline("+object+")";

                # save to the csv file
                addToKb([str(expression)])  
                msg = 'OK, I will remember that'+ object +'is'+ subject
                responseHelper('OK, I will remember that '+ object +' is '+ subject)
                    
        elif cmd == 32:
            #check if statemets
            object,subject=params[1].split(' is ')
            expr=read_expr(subject + '(' + object + ')')
            
            if getAnswer(2, expr):
                responseHelper("Sorry, I don't know") 
            
        
        elif cmd == 20:
              #check for the image
              # open upload window.  
              responseHelper("Select image path");
              file_path = getFile();
              if not file_path:
                  responseHelper("No file provided.")
              else:
                  responseHelper(math_classifier.getNum(file_path, model));
        elif cmd == 21:
              #check for the image
              # open upload window.  
              responseHelper("Select video path");
              file_path = getFile();
              if not file_path:
                  responseHelper("No file provided.")
              else:
                  responseHelper(math_classifier.getNumFromVideo(file_path, model)); # replce with video method

        elif cmd == 22:
             #start the game
              responseHelper("To play this game, you must use your keyboard.")
              responseHelper("Let's play!!")
              fg.mathGame()
             
        elif cmd == 99:
            # check the Q&A file for response 
            answerIndex = getResponeQA(userInput)
            # when no anser is found
            if answerIndex == -1:
                # no response found
                responseHelper("I did not get that, please try again.")
            else:
                # print response
                responseHelper(csvAnswers[answerIndex])
                
    else:
        ## make the read 
        responseHelper(answer)
        ## make retun the sattements 


def readResponse(respone):
    engine = pyttsx3.init()
    voices = engine.getProperty("voices")
    engine.setProperty("voice", voices[1].id)
    engine.setProperty("rate", 150)
    engine.say(respone)
    engine.runAndWait()

def getCommand():
    init_rec = sr.Recognizer()
    readResponse("Your command:")
    
    try:
        with sr.Microphone() as source:
            audio_data = init_rec.record(source, duration=5)
            readResponse("Recognising command")
            text = init_rec.recognize_google(audio_data)
           # print(text)
            readResponse(text)
            print("\nYour command:", text)
            return text
    except sr.UnknownValueError:
        print("\nSorry, I could not understand what you said.")
        readResponse("Sorry, I could not understand what you said.")
        return " "

#######################################################
# Main loop
#######################################################
print("Welcome to math chat bot. Please feel free to ask questions to me!  Use 'Quit' command to exit.")
readResponse("Welcome to math chat bot. Please feel free to ask questions to me! Use 'Quit' command to exit.")
user_selection = "true"
readResponse("To stop announcing commands enter or say stop")
while True:
    #get user input

    if not user_selection == "stop":
        user_selection = getCommand() 
        if user_selection == "stop":
           readResponse("To restrat announcing commands enter read")
        elif user_selection == "quit":
            readResponse("Thanks for chatting with the math bot! Happy mathing! Bye!")
            break
        elif not user_selection.isspace():
            getUserResponse(user_selection)
    
    if user_selection == "stop":
        try:
            userInput = input("\nUser: ")
            if user_selection == "quit":
                readResponse("Thanks for chatting with the math bot! Happy mathing! Bye!")
                break
            elif userInput.lower() == "read":
                readResponse("Announcing commands activated, enter or say stop to deactive commands reading")
                user_selection = "true"
            else:
                getUserResponse(userInput)
        except (KeyboardInterrupt, EOFError) as e:
            print("Bye!")
            break     

        
    
        


