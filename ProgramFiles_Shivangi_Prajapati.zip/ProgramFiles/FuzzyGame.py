# -*- coding: utf-8 -*-
"""
Created on Mon Mar 11 11:38:22 2024

@author: shiva
"""

from simpful import *
import random

# A simple fuzzy inference system for the tipping problem
# Create a fuzzy system object
FS = FuzzySystem()

# Define fuzzy sets and linguistic variables
# diffuclyt level of the questions
D_1 = FuzzySet(function=Triangular_MF(a=0, b=1, c=4), term="low") #0 -3
D_2 = FuzzySet(function=Triangular_MF(a=4, b=5, c=7), term="medium")  # 3-5 
D_3 = FuzzySet(function=Triangular_MF(a=7, b=10, c=10), term="high") # 5-10
FS.add_linguistic_variable("Difficulty", LinguisticVariable([D_1, D_2, D_3], concept="Difficutly level", universe_of_discourse=[0,10]))

# correctness of the given answer
C_1 = FuzzySet(function=Triangular_MF(a=0, b=1, c=5), term="low")
C_2 = FuzzySet(function=Triangular_MF(a=0, b=5, c=10), term="medium")
C_3 = FuzzySet(function=Triangular_MF(a=5, b=10, c=10), term="high")
FS.add_linguistic_variable("Correctness", LinguisticVariable([C_1, C_2, C_3], concept="Correctness level", universe_of_discourse=[0,10]))

# Define output fuzzy sets and linguistic variable for performace
P_1 = FuzzySet(function=Triangular_MF(a=0, b=1, c=5), term="bad")   # 0-3
P_2 = FuzzySet(function=Triangular_MF(a=0, b=5, c=10), term="good") # 3-10
P_3 = FuzzySet(function=Trapezoidal_MF(a=5, b=10, c=10), term="excellent") # 20-25
FS.add_linguistic_variable("Performance", LinguisticVariable([P_1, P_2, P_3], universe_of_discourse=[0,10]))


# update the diffculty
R1 = "IF (Correctness IS low) THEN ( Difficulty IS low )"
R2 = "IF (Correctness IS medium) THEN (Difficulty IS medium)"
R3 = "IF (Correctness IS high) THEN (Difficulty IS high)"
R4 = "IF (Correctness IS low) THEN (Performance IS bad)"
R5 = "IF (Correctness IS medium) THEN (Performance IS good)"
R6 = "IF (Correctness IS high) THEN (Performance IS excellent)"
FS.add_rules([R1, R2, R3, R4, R5, R6])


# Set antecedents values
# =============================================================================
# FS.set_variable("Correctness", 10)
# FS.set_variable("Difficulty", 10)
# 
# =============================================================================
# Perform Mamdani inference and print output
#print(FS.Mamdani_inference(["Performance"]))    

def getQuestion(difficulty_level):
    #required variabels
    operand1, operand2, operator, answer, question ="", "", "","",""
    
    ## if correctness is low, meaning questions are hard so ask simpler questions
    ## if corsectness 
    difficultyNum = difficulty_level['Difficulty']
    
    if difficultyNum >= 5 and difficultyNum <=10: #high
        operand1 = random.randint(1, 20)
        operand2 = random.randint(1, 20)
    elif difficultyNum>=3 and difficultyNum <=5: # medium
        operand1 = random.randint(1, 10)
        operand2 = random.randint(1, 10)
    else: # low
        operand1 = random.randint(1, 5)
        operand2 = random.randint(1, 5)
        
    operator = random.choice(['+', '-', '*', '/']) #select the operation to perform
    
    if operator == "+":
       answer = operand1 + operand2
    elif operator ==  "-":
       answer = operand1 - operand2
    elif operator == "*":
       answer = operand1 * operand2
    else:  # Division
       if operand2 == 0:  #prevent division by 0
           operand2 = 1
       answer = operand1 / operand2
       answer = round(answer, 2) ## answer to 2 decimal places
       
    # generates the question for the user
    question = f"What is {operand1} {operator} {operand2}?"

    return question, answer

def examineUserResponse(user_answer, correct_answer):
    # Define a tolerance, the allowed difference between the two answers
    tolerance = 0.5    
    # Check if the user's answer is within set range 
    # gets the number(regardless of the sign for when second value is greater than first)
    return abs(user_answer - correct_answer) <= tolerance

def getPerformance(correctnessScore):
    FS.set_variable("Correctness", correctnessScore)
    # get value
    performance_value = FS.Mamdani_inference(["Performance"])['Performance']   
    
    # Define a mapping between numerical values and linguistic terms
    term_mapping = {
        "bad": [0, 2.5],
        "good": [2.5, 5],
        "excellent": [5, 10]
    }

    # Find the term associated with the performance value
    performance_term = ""
    for term, (start, end) in term_mapping.items():
        if start <= performance_value < end:
            performance_term = term
            break
    
    # Print the performance value and its associated term
    print(f"\nYour Performance: {performance_term}")
    

    
def mathGame():
    print("\t\t------------------------------------------------------------")
    print("\t\t\t\t\tWelcome to the Fuzzy Math Quiz Game")
    print("\t\t------------------------------------------------------------")
    print("\nYou will be asked 8 arithmentic question. Give answers in interger or decimal(2dp).\n")
    
    #for intial difficulty, high correctness -> low difficulty  make sure easy questions are asked 
    FS.set_variable("Correctness", 1)
    
    pointsDeduct = 1.25 # 10/8
    totalPoints = 10
    
    correctnessScore = 1
    difficulty_level = FS.Mamdani_inference(["Difficulty"])
   # print(difficulty_level)
     # ask 8 questions 
    for q in range(8):
       difficulty_level = FS.Mamdani_inference(["Difficulty"])
      # print("c",correctnessScore)
           
       question, correct_answer = getQuestion(difficulty_level)
       #print(correct_answer)
         
       print("Question:",question)
       user_answer = ""
    
       while True:
           user_answer = input("Enter your answer (integer or decimal): ")  ## gets answers 
           if user_answer:
               try:
                    user_answer = float(user_answer)
                    break# no exception trown means all good
               except ValueError:
                    print("Invalid answer given!")

       # if incorrect answer than reduce the total score 
       if not examineUserResponse(user_answer, correct_answer):
           print("Incorrect!")
           totalPoints -=pointsDeduct
       else:
           print("Correct!")
           # correctness   ## get the correctnedds 
           
       # update the correctness to get accurate difficuty
       FS.set_variable("Correctness", totalPoints)
       print("=============================================================\n")
        
    # end of quiz 
    # performace check  
    getPerformance(totalPoints)   
    print("------------------------------------------------------------")
    print("\t\t\t\t\t\t\tQuiz end.")
    print("------------------------------------------------------------")
      


#mathGame()