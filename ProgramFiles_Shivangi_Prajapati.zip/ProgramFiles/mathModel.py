from tensorflow import keras
import numpy as np

mnist = keras.datasets.mnist

# Load data from the dataset 
(x_train, y_train), (x_test, y_test) = mnist.load_data()

#normalize
x_train, x_test = x_train / 255.0, x_test / 255.0

#resize
x_trainer = np.array(x_train).reshape(-1, 28, 28,1)
x_tester= np.array(x_test).reshape(-1, 28,28,1)

model = keras.Sequential([
     keras.Input(shape=(28,28,1)),
     keras.layers.Conv2D(filters=32, kernel_size=(3, 3), activation="relu"),
     keras.layers.MaxPooling2D(pool_size=(2, 2)),
     keras.layers.Conv2D(filters=64, kernel_size=(3, 3), activation="relu"),
     keras.layers.MaxPooling2D(pool_size=(2, 2)),
     keras.layers.Conv2D(filters=64, kernel_size=(3, 3), activation="relu"),
     keras.layers.Flatten(),
     keras.layers.Dense(64, activation="relu"),
     keras.layers.Dense(512, activation="relu"),
     keras.layers.Dense(32, activation="relu"),
     keras.layers.Dense(10, activation="softmax"),
   ])

model.compile(optimizer='adam',
             loss="sparse_categorical_crossentropy",             
              metrics=['accuracy'])

model.fit(x_trainer, y_train, epochs=15, batch_size=128) 
test_loss, test_acc = model.evaluate(x_test,  y_test, verbose=0)
print('\n Test accuracy:', test_acc)

model.save("mathModel.h5")

