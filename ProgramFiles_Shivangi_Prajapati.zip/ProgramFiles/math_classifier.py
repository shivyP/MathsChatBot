from tensorflow.keras.models import load_model
from PIL import Image, ImageOps
import numpy as np
import matplotlib.pyplot as plt
import cv2


def getNum(file_path, model):
    image = Image.open(file_path).convert('L')  # Convert to grayscale
    image = ImageOps.invert(image)
    image = image.resize((28, 28))  # Resize to 28x28
    image_array = np.array(image) / 255.0  # Normalize pixel values
    image_array = np.expand_dims(image_array, axis=0)  # Add batch dimension
    prediction = model.predict(image_array, verbose=0)
    predicted_label = np.argmax(prediction)
    
    response = "The predicted image is :"+ str(predicted_label)
   # print( "The predicted image is :", predicted_label)
    
    plt.imshow(image_array.reshape(28, 28), cmap='gray')
    plt.title(f"Predicted Digit: {predicted_label}")
    plt.axis('off')
    plt.show()
    return response

def getNumFromVideo(file_path, model):
    #load video
    video = cv2.VideoCapture(file_path)

    prediction_digits=[]
    #get frame per second 
    frame_per_second = video.get(cv2.CAP_PROP_FPS)
    frame_interval = int(frame_per_second)
    frame_count = 0
        
    ## do prediction for each frame 
    ## get each frame
    while True:
        isRead, frame = video.read()
        
        ## check if frame loading is successful 
        if not isRead:
            break; #exit
            
        frame_count+=1 #####
        # capture frame at each second and process it 
        if frame_count % frame_interval == 0:            
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            # Convert frame to PIL image
            pil_image = Image.fromarray(frame_rgb).convert('L')
            # Apply operations
            pil_image = ImageOps.invert(pil_image)
            pil_image = pil_image.resize((28, 28))  # Resize to 28x28
            
            # Convert image to numpy array and normalize
            image_array = np.array(pil_image) / 255.0

            image_array = np.expand_dims(image_array, axis=0)  # Add batch dimension
            prediction = model.predict(image_array, verbose=0)
            predicted_label = np.argmax(prediction)
            
           # print("Predic:",predicted_label )
            prediction_digits.append(predicted_label)
       
    video.release()



    # Convert predictions list to numpy array
    predictions_array = np.array(prediction_digits)

    # Get unique numbers from the predictions array
    unique_numbers = np.unique(predictions_array)
    #print("\n",predictions_array.size )
    # Print unique numbers
    response = "The video contains the following digits:"  
    for value in unique_numbers:
        response+=str(value)+" "
   # print("Unique numbers:", response)
    return response



